

#include <iostream>
#include<chrono>

#include "InputOutput.h"
#include "Geometry.h"
#include"Metric.h"
#include"Metric_OLD.h"
#include"Integrators.h"

#include<variant>
#include<random>

Point InputPoint()
{
    std::cout << "Enter a point: ";
    Point newpt{};
    for (auto& mem : newpt)
        std::cin >> mem;
    return newpt;
}

class Timer
{
private:
    // Type aliases to make accessing nested type easier
    using Clock = std::chrono::steady_clock;
    using Second = std::chrono::duration<double, std::ratio<1> >;

    std::chrono::time_point<Clock> m_beg{ Clock::now() };

public:
    void reset()
    {
        m_beg = Clock::now();
    }

    double elapsed() const
    {
        return std::chrono::duration_cast<Second>(Clock::now() - m_beg).count();
    }
};

TwoIndex tempmetric(const Point& p)
{
    // ScreenOutput("Kerr metric dd at " + toString(p));

    real m_aParam = 0.1;
    real r = p[1];
    real theta = p[2];
    real sint = sin(theta);
    real cost = cos(theta);
    real sigma = r * r + m_aParam * m_aParam * cost * cost;
    real delta = r * r + m_aParam * m_aParam - 2. * r;
    real A_ = (r * r + m_aParam * m_aParam) * (r * r + m_aParam * m_aParam)
        - delta * m_aParam * m_aParam * sint * sint;

    // Covariant metric elements
    real g00 = -(1. - 2. * r / sigma);
    real g11 = sigma / delta;
    real g22 = sigma;
    real g33 = A_ / sigma * sint * sint;
    real g03 = -2. * m_aParam * r * sint * sint / sigma;

    return TwoIndex{ {{g00, 0,0, g03 }, {0,g11,0,0}, {0,0,g22,0},{g03,0,0,g33}} };
}

int main()
{
    //std::cout << "Hello World!\n";

    SetOutputLevel(OutputLevel::Level_4_DEBUG);

    std::cout << "Enter a for Kerr: ";
    real thea;
    std::cin >> thea;

    std::cout << "Populating array of 10000 Points... ";
    std::array<Point, 1000> testarray{};
    std::random_device rd;  // Will be used to obtain a seed for the random number engine
    std::mt19937 gen(rd()); // Standard mersenne_twister_engine seeded with rd()
    std::uniform_real_distribution<> rvals(2.0, 10.0), thetavals(0.1, 0.8), phivals(0.0, 6.0);
    for (Point &r : testarray)
    {
        //r = Point{0,rvals(gen),thetavals(gen),phivals(gen)};
        r = Point{ 1,2,3,4 };
    }
    std::cout << "done.\n";
    std::cout << "First ten points are: \n";
    for (int i = 0; i < 10; ++i)
    {
        std::cout << toString(testarray[i]) << "\n";
    }

    Timer t;
  
    


    std::cout << "Looping through calling metric on all points NEW WAY... ";

    std::variant<KerrMetric> VarMetric{ KerrMetric{thea} };
    
    t.reset();
    getMetric_dd metricfunc{ {1,2,3,4} };
    for (int i = 0; i < 10000; ++i)
    {
        for (const Point& r : testarray)
        {
            //metricfunc.p = &r;
            TwoIndex temp = std::visit(metricfunc, VarMetric);
            if (temp[0][0] == r[0])
                std::cout << "Dummy so I don't get compiled away.\n";
        }
    }
    // timer end
    std::cout << " done in " << t.elapsed() << "s.\n";

    /// <summary>
    /// //////////////////
    /// </summary>
    /// <returns></returns>
    /// 

    std::cout << "Looping through calling metric on all points OLD WAY... ";


    Metric const* m = new KerrMetricOld{ thea };

    t.reset();
    Point dummy{ 1,2,3,4 };
    for (int i = 0; i < 10000; ++i)
    {
        for (const Point& r : testarray)
        {
            TwoIndex temp = m->getMetric_dd(dummy);
            if (temp[0][0] == r[0])
                std::cout << "Dummy so I don't get compiled away.\n";
        }
    }
    // timer end
    std::cout << " done in " << t.elapsed() << "s.\n";


    /// <summary>
    /// //////////////////
    /// </summary>
    /// <returns></returns>
    /// 

    std::cout << "Looping through calling metric on all points without any in-betweens.. ";



    t.reset();
    for (int i = 0; i < 10000; ++i)
    {
        for (const Point& r : testarray)
        {
            TwoIndex temp = tempmetric(dummy);
            if (temp[0][0] == r[0])
                std::cout << "Dummy so I don't get compiled away.\n";
        }
    }
    // timer end
    std::cout << " done in " << t.elapsed() << "s.\n";




    


    /*std::cout << "Enter coordinates: ";
    Point pt = InputPoint();
    std::cout << "Enter variable nr: ";
    int thevar;
    std::cin >> thevar;

    ScalarFunction tmp{ TestFunc };

    TwoIndexFunction test = [m](Point pt) {return m->getMetric_dd(pt); };*/


    //TwoIndexFunction temp{ m->getMetric_dd};

 //   ScreenOutput("Derivative of Kerr Metric at " + toString(pt) + " wrt variable " + std::to_string(thevar) + " is: \n"
 //      + toString(Integrators::PartialDerivative(test, pt, thevar)) + "\n");




}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu