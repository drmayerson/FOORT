#include"Integrators.h"
#include"InputOutput.h"

// This calculates the derivative of TheFunc(x) at x = TheX, using central difference
real Integrators::Derivative(const SingleVariableFunction& TheFunc, real TheX)
{
	return (TheFunc(TheX + Integrators::h_val) - TheFunc(TheX - Integrators::h_val)) / (2 * Integrators::h_val);
}