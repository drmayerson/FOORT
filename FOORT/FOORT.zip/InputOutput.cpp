#include"InputOutput.h"

// This is the output level; default is 1. Note: variable only accessible in this code file!
static OutputLevel theOutputLevel{ OutputLevel::Level_1_PROC };

// Set the output level
void SetOutputLevel(OutputLevel theLvl)
{
	theOutputLevel = theLvl;
}

// Outputs line to screen console), contingent on it being allowed by the set outputlevel
void ScreenOutput(std::string_view theOutput, OutputLevel lvl, bool newLine)
{
	if (static_cast<int>(lvl) <= static_cast<int>(theOutputLevel))	// Output is allowed at current set level
	{
		if (lvl == OutputLevel::Level_4_DEBUG)	// Print extra prefix to message for debug statements
		{
			std::cout << "DEBUG MSG: ";
		}
		std::cout << theOutput;
		if (newLine)				// We want the line to end after the message
		{
			std::cout << '\n';
		}
	}
}


// configobject ReadConfigFile(std::string_view theFile)
//{}

// GeodesicOutputHandler::...
