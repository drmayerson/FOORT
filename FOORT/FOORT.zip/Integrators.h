#ifndef _FOORT_INTEGRATORS_H
#define _FOORT_INTEGRATORS_H

#include<functional>
#include"Geometry.h"

// A single function of a single variable
using SingleVariableFunction = std::function<real(real)>;
// A scalar function of a spacetime point
using ScalarFunction = std::function<real(Point)>;
// A vector function of a spacetime point
using OneIndexFunction = std::function<OneIndex(Point)>;
// Tensor functions of a point
using TwoIndexFunction = std::function<TwoIndex(Point)>;
using ThreeIndexFunction = std::function<ThreeIndex(Point)>;

namespace Integrators
{
	constexpr real h_val{ 1e-10 };

	// This calculates the derivative of TheFunc(x) at x = TheX, using central difference
	real Derivative(const SingleVariableFunction& TheFunc, real theX);

	// Calculates the partial derivative of a Tensor (anything that is a function of a Point),
	// w.r.t. a certain variable (VarNr) at a point TheP,
	// using central difference
	template <typename TensorFunction>
	auto PartialDerivative(const TensorFunction& TheTensor, const Point& TheP, size_t VarNr)
	{
		Point MoveP{};
		MoveP[VarNr] = Integrators::h_val;
		return (TheTensor(TheP + MoveP) - TheTensor(TheP - MoveP)) / (2 * Integrators::h_val);
	}
}






#endif
