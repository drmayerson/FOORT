#include"Geometry.h"

#include"InputOutput.h"
#include"Integrators.h"

#include"Metric_OLD.h"

#include<cassert>

/// <summary>
/// Metric functions
/// </summary>

ThreeIndex Metric::getChristoffel_udd(const Point& p) const
{
	ScreenOutput("Called Christoffel at" + toString(p));

	getMetric_dd(p);

	return {};
}

FourIndex Metric::getRiemann_uddd(const Point& p) const
{
	ScreenOutput("Called Riemann at" + toString(p));

	return {};
}

real Metric::getKretschmann(const Point& p) const
{
	ScreenOutput("Called Kretschmann at" + toString(p));

	return 0;
}


/// <summary>
/// SelectMetric switch
/// </summary>
// Metric SelectMetric(configobject cfg);

/// <summary>
/// SphericalHorizonMetric functions
/// </summary>

SphericalHorizonMetric::SphericalHorizonMetric(real HorizonRadius, real AtHorizonEps)
	: m_HorizonRadius{ HorizonRadius }, m_AtHorizonEps{AtHorizonEps}
{}

Term SphericalHorizonMetric::InternalTerminate(const Point& p) const
{
	Term ret = Term::term_Continue;
	// Check to see if radius is almost at horizon
	if (p[1] < m_HorizonRadius * (1+m_AtHorizonEps))
		ret = Term::term_Horizon;
	return ret;
}


/// <summary>
/// KerrMetricOld functions
/// </summary>


KerrMetricOld::KerrMetricOld(real aParam,real atHorizonEps) 
	: m_aParam{ aParam }, SphericalHorizonMetric(1+sqrt(1-m_aParam*m_aParam),atHorizonEps)
{
	assert(dimension == 4 && "Cannot construct Kerr metric in spacetime dimension other than 4!");
}

TwoIndex KerrMetricOld::getMetric_dd(const Point& p) const
{
	// ScreenOutput("Kerr metric dd at " + toString(p));

	real r = p[1];
	real theta = p[2];
	real sint = sin(theta);
	real cost = cos(theta);
	real sigma = r * r + m_aParam * m_aParam * cost * cost;
	real delta = r * r + m_aParam * m_aParam - 2. * r;
	real A_ = (r * r + m_aParam * m_aParam) * (r * r + m_aParam * m_aParam)
		- delta * m_aParam * m_aParam * sint * sint;

	// Covariant metric elements
	real g00 = -(1. - 2. * r / sigma);
	real g11 = sigma / delta;
	real g22 = sigma;
	real g33 = A_ / sigma * sint * sint;
	real g03 = -2. * m_aParam * r * sint * sint / sigma;

	return TwoIndex{ {{g00, 0,0, g03 }, {0,g11,0,0}, {0,0,g22,0},{g03,0,0,g33}} };
}


TwoIndex KerrMetricOld::getMetric_uu(const Point& p) const
{
	ScreenOutput("Kerr metric uu at " + toString(p));
	return{};
}
