#ifndef _FOORT_INPUTOUTPUT_H
#define _FOORT_INPUTOUTPUT_H

#include<string_view>
#include<iostream>
#include<string>


// Determines at what priority level the output is generated to the console.
enum class OutputLevel
{
	Level_0_NONE = 0,		// No output at all
	Level_1_PROC = 1,		// Coarsest level output; only the major procedures produce output
	Level_2_SUBPROC = 2,	// Subprocedures can also produce output
	Level_3_ALLDETAIL = 3,	// Finest level output; all details are shown
	Level_4_DEBUG = 4		// Finest level output AND debug messages as well
};



// Set the output level
void SetOutputLevel(OutputLevel theLvl);

// Outputs line to screen console), contingent on it being allowed by the set outputlevel
void ScreenOutput(std::string_view theOutput, OutputLevel lvl = OutputLevel::Level_3_ALLDETAIL, bool newLine = true);


// configobject ReadConfigFile(std::string_view theFile);

// class GeodesicOutputHandler {};







#endif
