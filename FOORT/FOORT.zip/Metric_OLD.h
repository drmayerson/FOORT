#ifndef _FOORT_METRIC_OLD_H
#define _FOORT_METRIC_OLD_H

#include"Geometry.h"
#include"Metric.h"

// Termination conditions; can be set by the Metric OR by Terminations
//enum class Term
//{
//	term_Continue = 0,		// All is right, continue integrating geodesic
//	term_Horizon,			// STOP, encountered horizon (set by Metric)
//	term_Singularity,		// STOP, encountered singularity/center (set by Metric)
//	term_BoundarySphere,	// STOP, encountered boundary sphere (set by Termination::BoundarySphereTermination)
//	term_TimeOut,			// STOP, taken too many steps (set by Termination::TimeOutTermination)
//
//	term_Maxterms			// Number of termination conditions that exist
//};


// The abstract base class for all Metrics.
class Metric
{
public:
	// Get the metric, indices down
	virtual TwoIndex getMetric_dd(const Point& p) const = 0;	
	// Get the metric, indices up
	virtual TwoIndex getMetric_uu(const Point& p) const = 0;	

	// Check if there is an internal termination condition satisfied (horizon, singularity),
	// otherwise returns term_Continue if all is well
	virtual Term InternalTerminate(const Point& p) const = 0;

	// These return the Christoffel and other derivative quantities of the metric. They are computed for any
	// metric, BUT are left as virtual functions to allow for other metrics to implement their own (more efficient)
	// way of calculating them, if so desired.
	// 
	// Get the Christoffel symbol, indices up-down-down
	virtual ThreeIndex getChristoffel_udd(const Point& p) const;
	// Get the Riemann tensor, indices up-down-down-down
	virtual FourIndex getRiemann_uddd(const Point& p) const;
	// Get the Kretschmann scalar
	virtual real getKretschmann(const Point& p) const;
};

// Metric SelectMetric(configobject cfg);


// The type of metric that has a spherical horizon
class SphericalHorizonMetric : public Metric
{
protected:
	// Radius of the horizon
	real m_HorizonRadius;
	// Relative distance to the horizon for termination
	real m_AtHorizonEps;
public:
	// No default construction allowed, must specify horizon radius
	SphericalHorizonMetric() = delete;
	// Constructor that initializes radius and distance to horizon necessary for termination
	SphericalHorizonMetric(real HorizonRadius, real AtHorizonEps);

	// Is p at the horizon?
	virtual Term InternalTerminate(const Point& p) const;
};



// The Kerr metric
class KerrMetricOld : public SphericalHorizonMetric
{
private:
	real m_aParam;

public:

	// No constructor without passing parameters, and no copies allowed
	KerrMetricOld() = delete;
	KerrMetricOld(const KerrMetricOld& other) = delete;
	KerrMetricOld& operator=(const KerrMetricOld& other) = delete;

	// Constructor setting paramater a
	KerrMetricOld(real aParam=0.0, real AtHorizonEps=0.01);

	TwoIndex getMetric_dd(const Point& p) const final;
	// Get the metric, indices up
	TwoIndex getMetric_uu(const Point& p) const final;
};

class PlaceHolderMetricOld : public SphericalHorizonMetric
{
public:
	TwoIndex getMetric_dd(const Point& p) const final;
	TwoIndex getMetric_uu(const Point& p) const final;
};



#endif
